<?php
session_start();
  $hasError=0;
  $unameErr = "";
  $idErr = "";
  $ageErr = "";
  $passErr = "";
  $emailErr = "";
  $fileErr = "";
  $GanderErr ="";
  $religionErr ="";
  $numberErr = "";
  $Gander="";
  $religion="";
  $formdata ="";
  $filepath ="";
if(isset($_POST["Submit"]))
{
  
$name = $_POST["uname"];
$id = $_POST["id"];
$age = $_POST["age"];
$number = $_POST["number"];
$pass = $_POST["pass"];
$email = $_POST["email"];
if(isset($religion))
{
    $religionErr = 'You Havent Selected a checkbox';
}
else{$religion = $_POST["religion"] ;}
if(isset($Gander))
{
    $GanderErr = 'You have not selected any Gander';
}
else{$Gander= $_POST["Gander"];}


    

        if (empty($uname))
    {
        $unameErr ='Please Enter  UserName';
        $hasError =1;
    }
      else if(is_numeric($uname))
      {
        $unameErr =' UserName can not be numeric';
        $hasError =1;
      }
         else
    {
        echo 'Your UserName is ' . $uname;
        $_SESSION["uname"]= $uname;
    }
   // echo '<br>';

    


    

        if (empty ($age))
    {
        $ageErr= 'Please Enter your Age ';
    } else
    {
       // echo 'Your Age is ' . $age;
    }

    //echo '<br>';
   
    if (
        isset($Gander) )
        {
        if ("Male"==$Gander) {
            $GanderErr = 'You selected Male ';
         
        }
        if ($Gander=='Female') {
            $GanderErr = 'You selected Female';
         
        }
        
    } else {
        $GanderErr = 'You have not selected any Gander';
    }

    echo '<br>';

   
    if (
        isset($_POST['religion1']) ||
        isset($_POST['religion2']) ||
        isset($_POST['religion3'])||
        isset($_POST['religion4'])) {
        if (isset($_POST['religion1'])) {
            $religionErr = 'Your Have Selected Islam ';
            $religion = $religion. $_POST['religion1'];
            echo '<br>';
        }
    
        if (isset($_POST['religion2'])) {
            $religionErr = 'Your Have Selected Hindu';
            $religion =  $religion.''.$_POST['religion2'];
            echo '<br>';
        }
        if (isset($_POST['religion3'])) {
            $religionErr = 'Your Have Selected Christian';
            $religion = $religion.''. $_POST['religion3'];
            echo '<br>';
        }
        if (isset($_POST['religion4'])) {
            $religionErr = 'Your Have Selected Buddha';
            $religion = $religion.''. $_POST['religion4'];
            echo '<br>';
        }
    }
    
      else {
        $religionErr = 'You Have not Selected a checkbox';
        echo '<br>';
    }


  

    if(empty($email)  )
    {
        $emailErr = "You must enter email";
    } 
    else if(!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email))
    { $emailErr = "Wrong Pattern Email";} 
    else{
     // echo "Your email is ".$email;
      echo '<br>';
    }

    
    if (strlen($pass) < 5) {
        $passErr =  'Enter a valid password';
    } else
     {
        echo 'password is valid';
    }

    if (strlen($number) < 11) {
        $numberErr =  'phone number must be 11 digits';
    } else
     {
        echo 'phone number entered.';
    }

echo $_FILES["myfile"]["name"];
 

if(move_uploaded_file($_FILES["myfile"]["tmp_name"],"../uploads/".$_FILES["myfile"]["name"]))
{ $filepath = "../uploads/".$_FILES["myfile"]["name"];
    $fileErr = "File Uploaded";
}

else
$fileErr = 'Upload Error';

$formdata = array(
    'username'=>$_POST["uname"],
    'id'=>$_POST["id"],
    'age'=>$_POST["age"],
    'pass'=>$_POST["pass"],
    'email'=>$_POST["email"],
    'phone number'=>$_POST["number"],
    'religion'=>$religion,
    'Gander'=>$_POST["Gander"],
    'filepath'=>$filepath

    

);
$existingdata = file_get_contents('../data/data.json');
$tempJSONdata = json_decode($existingdata);
$tempJSONdata[] =$formdata;


$jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
if(file_put_contents("../data/data.json",$jsondata))
{
    echo 'Data Successfully Saved';
}
else
echo 'No Data Saved';


/*$data = file_get_contents("../data/data.json");
$mydata= json_decode($data,true);

foreach($mydata as $data)
     {
     foreach($data as $key=>$value)
    {
        echo $key." => ".$value."<br>";
    } 
    }
    */


    $string = file_get_contents("../data/data.json");
$json = json_decode($string, true);

foreach ($json as $key => $value) {
    if (!is_array($value)) {
        echo $key . '=>' . $value . '<br />';
    } else {
        foreach ($value as $key => $val) {
            echo $key . '=>' . $val . '<br />';
        }
    }
}
}







?>

