<?php
include("../control/Executive_Officer_process.php");

?>
<head>
    <body>
   
        <h1>  executive officer Registration Form </h1>
       
        <form action ="" method ="post" enctype ="multipart/form-data"> 
            <table>
            
    <tr>
        <td>
         UserName : </td><td><input type= "text" name ="uname" > <?php echo $unameErr; ?>  
       
        </td>
    </tr>


    <tr>
        <td>
         ID : </td><td><input type= "text" name ="id" >  <?php echo $idErr; ?> 
       
        </td>
    </tr>



    <tr>
        <td>
        Age :    </td><td> <input type ="number" name ="age" min="0" max="80"> <?php echo $ageErr; ?> 
        </td>
    </tr>


    <tr>
        <td>
        Gander : </td><td><input type = "radio" name = "Gander" value ="Male">Male 
                          <input type = "radio" name = "Gander" value ="Female">Female <?php echo $GanderErr; ?>
        </td>
    </tr>


    <tr>
        <td>
    Religion :  </td><td>        
    <input type="checkbox" name="religion1"  value="Islam" >Islam
    <input type="checkbox" name="religion2"  value="Hindu"> Hindu
    <input type="checkbox" name="religion3"  value="Christian"> Christian
    <input type="checkbox" name="religion4"  value="Buddha"> Buddha <?php echo $religionErr; ?>
        </td>
    </tr>


    <tr>
        <td>
   Email :</td><td> <input type ="email" name = "email" >  <?php echo $emailErr; ?>
        </td>
    </tr>


    <tr>
        <td>
    phone Number: </td><td><input type ="text" name = "number" ><?php echo $numberErr; ?>
        </td>
</tr>


<tr>
    <td>
         Password :</td><td> <input type ="password" name ="pass"><?php echo $passErr; ?>
    </td>
</tr>




<tr>
     <td>
      Please choose a file</td><td><input type="file" name ="myfile"> <?php echo $fileErr; ?>
     
    </td>
</tr>


<tr>
    <td>
    <input type ="submit" name="Submit" value= "submit" >
    <input type = "reset">
    <a href="../control/logout.php">back</a></h5>

    </td>
</tr>

    

</form>
    </table>
    
    </body>
    </head>